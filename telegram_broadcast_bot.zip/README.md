
# Telegram Broadcast Bot
## Cara Instalasi

1. Install semua dependensi:
   ```
   pip install -r requirements.txt
   ```

2. Ganti `TOKEN`, `API_ID`, dan `API_HASH` pada file `bot.py` dengan milik Anda sendiri.

3. Jalankan bot:
   ```
   python bot.py
   ```

4. Untuk melakukan broadcast, kirim pesan dengan format:
   ```
   /broadcast <pesan>
   ```

5. Bot akan otomatis join ke obrolan suara grup yang ditentukan di `join_voice_chat`.

6. **(Optional)** Setup web dashboard dengan Flask untuk broadcast dari browser.

## API_ID dan API_HASH
Daftar API_ID dan API_HASH di [my.telegram.org](https://my.telegram.org/) untuk membuat aplikasi Telegram baru dan mendapatkan kredensial API.

    