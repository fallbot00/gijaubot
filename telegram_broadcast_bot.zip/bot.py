
import json
import asyncio
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes
from telethon import TelegramClient
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger

# ==== SETTING ===
TOKEN = 'ISI_TOKEN_BOT_DISINI'  # Token dari @BotFather
ADMIN_IDS = [123456789]  # Ganti dengan user ID Admin yang boleh /broadcast
CHAT_ID_FILE = 'chat_ids.json'
API_ID = 'ISI_API_ID_ANDA'
API_HASH = 'ISI_API_HASH_ANDA'

# ==== FUNGSI DATABASE ===
def load_chat_ids():
    try:
        with open(CHAT_ID_FILE, 'r') as f:
            return set(json.load(f))
    except (FileNotFoundError, json.JSONDecodeError):
        return set()

def save_chat_ids(chat_ids):
    with open(CHAT_ID_FILE, 'w') as f:
        json.dump(list(chat_ids), f)

chat_ids = load_chat_ids()

# ==== HANDLER ===
async def save_chat(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    chat_ids.add(chat_id)
    save_chat_ids(chat_ids)

async def broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text("Maaf, Anda tidak diizinkan menggunakan perintah ini.")
        return
    
    if not context.args:
        await update.message.reply_text("Format salah. Gunakan: /broadcast <pesan>")
        return

    message = ' '.join(context.args)
    success = 0
    failed = 0

    for cid in chat_ids:
        try:
            await context.bot.send_message(chat_id=cid, text=message)
            await asyncio.sleep(0.05)  # Delay supaya tidak ban
            success += 1
        except Exception as e:
            print(f"Error sending to {cid}: {e}")
            failed += 1

    await update.message.reply_text(f"Broadcast selesai. Sukses: {success}, Gagal: {failed}")

# ==== JOIN VOICE CHAT ===
async def join_voice_chat():
    client = TelegramClient('bot_session', API_ID, API_HASH)
    await client.start()
    group_id = "NamaGrupAnda"  # Ganti dengan ID atau nama grup tempat Voice Chat
    await client.join_group_call(group_id)
    print("Bot berhasil join Voice Chat!")

# ==== SCHEDULER ====
def setup_scheduler():
    scheduler = AsyncIOScheduler()
    scheduler.add_job(join_voice_chat, IntervalTrigger(seconds=600))  # Join setiap 10 menit
    scheduler.start()

# ==== SETUP ===
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Halo! Bot Broadcast aktif.")

def main():
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler('start', start))
    app.add_handler(CommandHandler('broadcast', broadcast))
    app.add_handler(MessageHandler(filters.ALL, save_chat))

    setup_scheduler()
    
    print("Bot mulai...")
    app.run_polling()

if __name__ == '__main__':
    main()
